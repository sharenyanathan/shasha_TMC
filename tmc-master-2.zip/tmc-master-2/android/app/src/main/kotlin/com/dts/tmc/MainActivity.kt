package com.dts.tmc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
