String token = '';
int notificationCount = 0;
