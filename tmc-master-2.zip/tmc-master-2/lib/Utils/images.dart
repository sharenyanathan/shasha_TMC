

class Images {
  static final String alert = "assets/images/alerts.png";
}