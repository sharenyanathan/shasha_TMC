// import 'package:flutter/material.dart';

// showCustomFlushBar(context, String msg, int duration) {
//   Scaffold.of(context).show
//   SnackBar(
//     margin: EdgeInsets.all(8),
//     icon: Icon(
//       Icons.info_outline,
//       size: 20,
//       color: Colors.lightBlue[800],
//     ),
//     duration: Duration(seconds: duration),
//   );
// }
